import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroadd',
  template: `
    <p>
      heroadd works!
    </p>
  `,
  styles: []
})
export class HeroaddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
