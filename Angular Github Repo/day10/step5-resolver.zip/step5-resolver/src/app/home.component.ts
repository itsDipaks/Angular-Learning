import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Home Component</h1>
    <hr>
  `,
})
export class HomeComponent {
}
