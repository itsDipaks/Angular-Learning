import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batman',
  template: `
    <h1>
      batman works!
    </h1>
  `,
  styles: [
  ]
})
export class BatmanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
