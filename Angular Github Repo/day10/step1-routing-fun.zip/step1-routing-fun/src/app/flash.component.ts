import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flash',
  template: `
    <h1>
      flash works!
    </h1>
  `,
  styles: [
  ]
})
export class FlashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
