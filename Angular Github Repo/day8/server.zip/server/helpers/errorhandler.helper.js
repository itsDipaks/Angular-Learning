let errorHandler = function(error){  console.log("Error is ", error) };

module.exports = errorHandler;